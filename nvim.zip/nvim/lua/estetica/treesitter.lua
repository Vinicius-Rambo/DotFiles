
return {
  "nvim-treesitter/nvim-treesitter",
  build = ":TSUpdate",
  opts = {
    ensure_installed = {
      "c",
      "cpp",
      "java",
      "php",
      "html",
      "css",
      "bash",
      "lua",
      "json",
      "sql",
      "yaml",
      "javascript",
      "tsx",
      "markdown",
      "markdown_inline",
    },
    highlight = { enable = true },
    indent = { enable = true },
    autopairs = { enable = true },
    autotag = { enable = true },
  },
  config = function(_, opts)
    require("nvim-treesitter.configs").setup(opts)
    -- Habilitar autotag se instalado
    pcall(function()
      require("nvim-ts-autotag").setup()
    end)
  end,
}
