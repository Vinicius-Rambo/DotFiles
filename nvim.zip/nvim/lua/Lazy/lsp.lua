
return {
  "neovim/nvim-lspconfig",
  dependencies = {
    "williamboman/mason.nvim",
    "williamboman/mason-lspconfig.nvim",
  },
  config = function()
    require("mason").setup()

    require("mason-lspconfig").setup({
      ensure_installed = {
        "clangd",
        "jdtls",
        "intelephense",
        "html",
        "cssls",
        "emmet_ls",
        "bashls",
        "sqls",
        "lua_ls",
      },
    })

    local lspconfig = require("lspconfig")

    lspconfig.clangd.setup({})
    lspconfig.jdtls.setup({})
    lspconfig.intelephense.setup({})
    lspconfig.html.setup({})
    lspconfig.cssls.setup({})
    lspconfig.emmet_ls.setup({})
    lspconfig.bashls.setup({})
    lspconfig.sqls.setup({})

    -- Lua para o próprio Neovim
    lspconfig.lua_ls.setup({
      settings = {
        Lua = { diagnostics = { globals = { "vim" } } },
      },
    })
  end,
}
