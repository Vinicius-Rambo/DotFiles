return {
  "barrett-ruth/live-server.nvim",
  build = "npm install -g live-server", -- precisa do live-server no sistema
  cmd = { "LiveServerStart", "LiveServerStop", "LiveServerToggle" },
  config = function()
    require("live-server").setup()

    -- Comando customizado :Live
    vim.api.nvim_create_user_command("Live", function()
      vim.cmd("LiveServerToggle")
    end, {})

    print("Comando :Live carregado!")
  end,
}
