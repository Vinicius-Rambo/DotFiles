return {
	"Rambo/runner.nvim",

	config = function()
		local M = {}

		-- Detecta linguagem
		local function detect_language()
			local ft = vim.bo.filetype

			if ft == "c" or ft == "cpp" then
				return "c"
			elseif ft == "java" then
				return "java"
			elseif ft == "python" then
				return "python"
			elseif ft == "sh" then
				return "bash"
			else
				return nil
			end
		end

		-- Compilar
		function M.compile()
			local lang = detect_language()
			if not lang then
				print("Linguagem não suportada.")
				return
			end

			local file = vim.fn.expand("%:p")
			local dir = vim.fn.expand("%:p:h")
			local name = vim.fn.expand("%:t:r")

			-- C
			if lang == "c" then
				local cmd = string.format('gcc "%s" -o "%s/%s"', file, dir, name)
				vim.cmd("!" .. cmd)
				print("Compilado: " .. name)
			end

			-- Java
			if lang == "java" then
				local cmd = string.format('javac "%s"', file)
				vim.cmd("!" .. cmd)
				print("Compilado: " .. name .. ".class")
			end

			-- Python não compila (interpretação)
			if lang == "python" then
				print("Python não precisa compilar.")
			end

			-- Bash também não compila
			if lang == "bash" then
				print("Shell script não precisa compilar.")
			end
		end

		-- Compilar + Executar
		function M.compile_execute()
			local lang = detect_language()
			if not lang then
				print("Linguagem não suportada.")
				return
			end

			local file = vim.fn.expand("%:p")
			local dir = vim.fn.expand("%:p:h")
			local name = vim.fn.expand("%:t:r")

			M.compile()

			-- Executar C
			if lang == "c" then
				vim.cmd('!"' .. dir .. "/" .. name .. '"')
			end

			-- Executar Java
			if lang == "java" then
				vim.cmd('!java -cp "' .. dir .. '" ' .. name)
			end

			-- Executar Python
			if lang == "python" then
				vim.cmd('!python3 "' .. file .. '"')
			end

			-- Executar Bash
			if lang == "bash" then
				vim.cmd('!bash "' .. file .. '"')
			end
		end

		-- Keymap F5
		vim.keymap.set("n", "<F5>", function()
			M.compile_execute()
		end, { desc = "Compilar e executar arquivo atual" })

		-- Comandos
		vim.api.nvim_create_user_command("Compile", function()
			M.compile()
		end, {})

		vim.api.nvim_create_user_command("CompileExecute", function()
			M.compile_execute()
		end, {})
	end,
}
