require("lazy").setup({
  { import = "estetica" },
  { import = "customizados" },
  { import = "kickstarter" },
})
